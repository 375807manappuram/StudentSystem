﻿using Microsoft.EntityFrameworkCore;
using project_student.Controllers;
using project_student.Models;

namespace project_student.data
{
    public class ApplicationDbContext : DbContext
    {
        
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
            {

            }
            public DbSet<Student> Students { get; set; }

            public DbSet<Course> Courses { get; set; }

            public DbSet<Enrollment> Enrollments { get; set; }
        }
    }
