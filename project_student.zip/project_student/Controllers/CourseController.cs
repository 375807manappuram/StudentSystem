﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project_student.data;
using project_student.Models;

namespace project_student.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CourseController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpPost("AddCourses")]
        public async Task<IActionResult> AddCourses([FromBody] Course course)
        {
            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return Ok(course);
        }
        [HttpGet("GetCourses")]
        public async Task<IActionResult> GetCourses()
        {
            var CourseNew = await _context.Courses.ToListAsync();
            return Ok(CourseNew);
        }
    }
}
