﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using project_student.data;
using project_student.Models;

namespace project_student.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public EnrollmentsController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpPost("AddEnrollments")]
        public async Task<IActionResult> AddEnrollments([FromBody] Enrollment enrollment)
        {
            _context.Enrollments.Add(enrollment);
            await _context.SaveChangesAsync();
            return Ok(enrollment);
        }
        [HttpGet("GetEnrollments{Id}")]
        public async Task<IActionResult> GetEnrollments(int Id)

        {
            var EnrollmentsNew = await _context.Enrollments.FindAsync(Id);
            return Ok(EnrollmentsNew);
        }
    }
}