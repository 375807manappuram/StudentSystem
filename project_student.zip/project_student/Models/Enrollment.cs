﻿namespace project_student.Models
{
    public class Enrollment
    {
        public int Id {  get; set; }
        public int StudentId { get; set; }
        public int courseId { get; set; }
        public DateTime EnrollmentDate { get; set; }
    }
}
